<?php
    echo "Your mail is <b>".$_POST['email']."</b>";
?>