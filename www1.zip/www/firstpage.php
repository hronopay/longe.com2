<?php 
echo '
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta charset="UTF-8">


<link rel="stylesheet" type="text/css" href="css/firstpage.css" />
</head>
<body>


'.$langMenu.'


<div style="position:absolute; left:'.$pos1.'px; top:15px; ">
<h4>'.$t1.'</h4>
</div>
<div style="position:absolute; left:200px; top:85px; ">
<h2>'.$t2.'</h2>
</div>
<h1>'.$t3.'</h1>



<div style="position:absolute; left:500px; top:450px; ">
<h3><a href="gfhfh.com">'.$t4.'</a></h3>
</div>


<div style="position:absolute; left:720px; top:450px; ">
<h3><a href="gfhfh.com">'.$t5.'</a></h3>
</div>


<div style="position:absolute; left:880px; top:450px; ">
<h3><a href="signup">'.$t6.'</a></h3>
</div>


<div style="position:absolute; left:720px; top:550px; ">
<h3><a href="market">'.$t7.'</a></h3>
</div>


</body>
</html>';

//phpinfo(32);
?>