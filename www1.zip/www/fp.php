<!DOCTYPE html>
<html>
<head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta charset="UTF-8">


<link rel="stylesheet" type="text/css" href="css/firstpage.css" />
<!--link href="jquery-ui.css" rel="stylesheet"-->
<script>
//$( "#selectmenu" ).selectmenu();
/*
$( "#selectmenu" ).on( "selectmenuchange", function() {
	
    	alert( "Please enter some text!" );
  	
} );

$( "#selectmenu" ).selectmenu({
  change: function( "blur", ui ) {alert( "Please enter some text!" );}
});




function submit_by_id() {
var name = document.getElementById("language1").value;

document.getElementById("language1").submit(); //form submission
alert(" Name : " + name  + " n Form Id : " + document.getElementById("form_id").getAttribute("id") + "nn Form Submitted Successfully......");
}
*/

</script>
</head>
<body>

<div class="lang1" style="position:absolute; left:1400px; top:10px; ">
<form id="language1" action="langcookie.php" method="get" name="checklang" enctype="text/plain">
<select id="selectmenu" name="language" onChange="form.submit();">
	<option value="ru">Русский</option>
	<option value="chi" >中国人</option>
	<option value="en" selected="selected">English</option>
</select>
<input type="hidden" name="redirectPage" value="'.$redirectPage.'">
</form>
</div>

<div style="position:absolute; left:165px; top:15px; ">
<h4>T</h4>
</div>
<div style="position:absolute; left:200px; top:85px; ">
<h2>ake your chance with the</h2>
</div>
<h1>BuySell<br>Project<br>Exchange</h1>



<div style="position:absolute; left:500px; top:450px; ">
<h3><a href="gfhfh.com">Learn more</a></h3>
</div>


<div style="position:absolute; left:720px; top:450px; ">
<h3><a href="gfhfh.com">Sign In</a></h3>
</div>


<div style="position:absolute; left:880px; top:450px; ">
<h3><a href="signup">Sign Up</a></h3>
</div>


<div style="position:absolute; left:710px; top:550px; ">
<h3><a href="market">Market</a></h3>
</div>


</body>
</html>

