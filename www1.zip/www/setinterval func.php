<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Немного музыки</title>
</head>
<body>


<script>

setInterval(function(){$('#my_div').load('cgi-glob/cgi-1.exe');}, 2000) /* time in milliseconds (ie 2 seconds)*/
	
</script>

<h1>Start</h1>

<div id="my_div">
</div>

<h1>End</h1>



</body>
</html>
