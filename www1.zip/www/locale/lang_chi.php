<?php 
$pos1 = '165';
$t1 = '';
$t2 ='抓住机会';
$t3 ='BuySell <br>项目<br> Exchange';
$t4 ='了解更多';
$t5 ='登录';
$t6 ='寄存器';
$t7 ='市场';
$t8 ='创建帐户';
$t9 ='个人帐户类型<span class ="comment">-个人交易</span>';
$t10 ='公司帐户类型<span class ="comment">-代表您的企业进行交易</span>';
$t11 ='电子邮件地址';
$t12 ='<strong>密码</ strong> <span class ="comment">（必须为<span style ="font-style：italic;"> </strong>密码，长度至少为12个字符）</span>';
$t13 ='创建帐户';
$t14 ='已经有一个帐户？ <a href="login">登录</a> <br> <br>我们努力遵守所有适用的规则，以帮助防止，检测和消除在BuySell Project中使用交易时客户和虚拟资产开发商的非法行为。平台或BuySell项目的任何其他服务。 ';
$t15 ='我们承诺遵守所有适用规则，以帮助防止，检测和消除使用BuySell Project交易平台或任何其他BuySell Project服务时客户和虚拟资产开发商的非法行为。';


?>